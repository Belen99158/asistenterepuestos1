// Backend del asistente de garantía — Cloudflare Pages Function.
// La ruta de archivo /functions/api/chat.js se publica como la URL /api/chat
// La clave vive en una variable de entorno del panel de Cloudflare (env.ANTHROPIC_API_KEY)
// y NUNCA llega al navegador.

import { SYSTEM_PROMPT } from "./_prompt.js";

// Modelo: "claude-haiku-4-5-20251001" es más barato y rápido,
// "claude-sonnet-4-6" (por defecto) razona mejor los dictámenes.
const MODEL = "claude-sonnet-4-6";

// En producción cambia "*" por tu dominio real, p. ej. "https://tu-empresa.com".
const ALLOWED_ORIGIN = "*";

const corsHeaders = {
  "Access-Control-Allow-Origin": ALLOWED_ORIGIN,
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
};

function json(obj, status) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: { "content-type": "application/json", ...corsHeaders },
  });
}

// Responde a la verificación CORS del navegador.
export function onRequestOptions() {
  return new Response(null, { status: 204, headers: corsHeaders });
}

// Maneja los mensajes del widget.
export async function onRequestPost(context) {
  const { request, env } = context;

  const apiKey = env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    return json(
      { error: "Falta configurar la variable de entorno ANTHROPIC_API_KEY." },
      500
    );
  }

  try {
    const body = await request.json();
    const messages = Array.isArray(body?.messages) ? body.messages : [];
    if (messages.length === 0) {
      return json({ error: "No se recibieron mensajes." }, 400);
    }

    // Límite simple para acotar conversaciones largas (y costos).
    const trimmed = messages.slice(-20);

    const anthropicRes = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: MODEL,
        max_tokens: 1024,
        system: SYSTEM_PROMPT,
        messages: trimmed,
      }),
    });

    if (!anthropicRes.ok) {
      const detail = await anthropicRes.text();
      return json({ error: "Error al consultar el asistente.", detail }, 502);
    }

    const data = await anthropicRes.json();
    const reply = (data.content || [])
      .filter((b) => b.type === "text")
      .map((b) => b.text)
      .join("\n")
      .trim();

    return json({ reply: reply || "Sin respuesta." }, 200);
  } catch (err) {
    return json({ error: "Error interno.", detail: String(err) }, 500);
  }
}
