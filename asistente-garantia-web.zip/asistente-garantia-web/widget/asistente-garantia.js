/*
 * Asistente de Garantía — widget embebible
 * --------------------------------------------------
 * Uso en cualquier página:
 *   <script src="ruta/asistente-garantia.js" data-endpoint="/api/chat"></script>
 *
 * data-endpoint: URL de tu backend (la función /api/chat). Por defecto "/api/chat".
 *
 * Usa Shadow DOM, así que sus estilos no afectan ni son afectados por tu sitio.
 */
(function () {
  "use strict";

  var script = document.currentScript;
  var ENDPOINT =
    (script && script.getAttribute("data-endpoint")) ||
    (window.ASISTENTE_GARANTIA_CONFIG &&
      window.ASISTENTE_GARANTIA_CONFIG.endpoint) ||
    "/api/chat";

  var WELCOME =
    "Hola 👋 Soy el asistente de garantías. Cuéntame qué repuesto falló y desde " +
    "cuándo lo tienes, y te ayudo a saber si podría aplicar la garantía.";

  // Estado de la conversación que se envía al backend.
  var history = [];
  var sending = false;

  // ---- Contenedor + Shadow DOM ----
  var host = document.createElement("div");
  host.setAttribute("id", "asistente-garantia-host");
  document.body.appendChild(host);
  var root = host.attachShadow({ mode: "open" });

  var styles = `
    :host { all: initial; }
    * { box-sizing: border-box; font-family: ui-sans-serif, system-ui, -apple-system, "Segoe UI", Roboto, sans-serif; }
    .mono { font-family: ui-monospace, "SFMono-Regular", Menlo, Consolas, monospace; }

    .launcher {
      position: fixed; right: 22px; bottom: 22px; z-index: 2147483000;
      display: inline-flex; align-items: center; gap: 10px;
      padding: 13px 18px 13px 15px; border: none; cursor: pointer;
      border-radius: 999px; background: #1c1f24; color: #fff;
      box-shadow: 0 8px 24px rgba(0,0,0,.28);
      font-size: 14px; font-weight: 600; letter-spacing: .2px;
      transition: transform .15s ease, box-shadow .15s ease;
    }
    .launcher:hover { transform: translateY(-2px); box-shadow: 0 12px 30px rgba(0,0,0,.34); }
    .launcher:focus-visible { outline: 3px solid #f5a623; outline-offset: 2px; }
    .dot {
      width: 9px; height: 9px; border-radius: 50%; background: #f5a623;
      box-shadow: 0 0 0 0 rgba(245,166,35,.7); animation: pulse 2.4s infinite;
    }
    @keyframes pulse {
      0% { box-shadow: 0 0 0 0 rgba(245,166,35,.6); }
      70% { box-shadow: 0 0 0 8px rgba(245,166,35,0); }
      100% { box-shadow: 0 0 0 0 rgba(245,166,35,0); }
    }
    @media (prefers-reduced-motion: reduce) {
      .dot { animation: none; }
      .launcher { transition: none; }
    }

    .panel {
      position: fixed; right: 22px; bottom: 22px; z-index: 2147483000;
      width: 380px; max-width: calc(100vw - 28px);
      height: 560px; max-height: calc(100vh - 28px);
      display: none; flex-direction: column; overflow: hidden;
      background: #f5f6f8; border-radius: 16px;
      box-shadow: 0 18px 50px rgba(0,0,0,.32);
      border: 1px solid rgba(0,0,0,.06);
    }
    .panel.open { display: flex; }

    .head {
      background: #1c1f24; color: #fff; padding: 15px 16px;
      display: flex; align-items: center; gap: 11px;
    }
    .head .title { font-size: 15px; font-weight: 700; line-height: 1.2; }
    .head .sub { font-size: 11px; color: #9aa3af; letter-spacing: .4px; text-transform: uppercase; }
    .head .badge {
      width: 34px; height: 34px; border-radius: 9px; flex: none;
      background: #2a2f37; display: grid; place-items: center;
      border: 1px solid rgba(245,166,35,.5);
    }
    .head .close {
      margin-left: auto; background: transparent; border: none; color: #9aa3af;
      cursor: pointer; font-size: 22px; line-height: 1; padding: 4px 6px; border-radius: 6px;
    }
    .head .close:hover { color: #fff; background: rgba(255,255,255,.08); }

    .log { flex: 1; overflow-y: auto; padding: 16px; display: flex; flex-direction: column; gap: 12px; }

    .msg { max-width: 86%; padding: 10px 13px; border-radius: 13px; font-size: 14px; line-height: 1.5; white-space: pre-wrap; word-wrap: break-word; }
    .msg.bot { align-self: flex-start; background: #fff; color: #1c1f24; border: 1px solid rgba(0,0,0,.06); border-bottom-left-radius: 4px; }
    .msg.user { align-self: flex-end; background: #1c1f24; color: #fff; border-bottom-right-radius: 4px; }
    .msg pre { background: #11141a; color: #e7eaf0; padding: 11px; border-radius: 9px; overflow-x: auto; font-size: 12px; margin: 6px 0 0; font-family: ui-monospace, Menlo, Consolas, monospace; white-space: pre; }
    .msg strong { font-weight: 700; }

    .typing { align-self: flex-start; display: flex; gap: 4px; padding: 12px 14px; background: #fff; border: 1px solid rgba(0,0,0,.06); border-radius: 13px; border-bottom-left-radius: 4px; }
    .typing span { width: 6px; height: 6px; border-radius: 50%; background: #9aa3af; animation: blink 1.4s infinite; }
    .typing span:nth-child(2){ animation-delay:.2s } .typing span:nth-child(3){ animation-delay:.4s }
    @keyframes blink { 0%,60%,100%{opacity:.25} 30%{opacity:1} }

    .foot { padding: 11px; background: #fff; border-top: 1px solid rgba(0,0,0,.06); }
    .row { display: flex; gap: 8px; align-items: flex-end; }
    textarea {
      flex: 1; resize: none; border: 1px solid rgba(0,0,0,.14); border-radius: 11px;
      padding: 10px 12px; font-size: 14px; max-height: 110px; min-height: 42px; outline: none; color: #1c1f24;
    }
    textarea:focus { border-color: #1c1f24; }
    .send {
      flex: none; width: 42px; height: 42px; border-radius: 11px; border: none; cursor: pointer;
      background: #f5a623; color: #1c1f24; display: grid; place-items: center;
    }
    .send:disabled { opacity: .45; cursor: default; }
    .send:focus-visible { outline: 3px solid #1c1f24; outline-offset: 2px; }
    .disclaimer { margin: 8px 2px 0; font-size: 10.5px; color: #6b7280; line-height: 1.4; }
  `;

  var wrench =
    '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#f5a623" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14.7 6.3a4 4 0 0 0-5.4 5.4L3 18v3h3l6.3-6.3a4 4 0 0 0 5.4-5.4l-2.3 2.3-2.1-.6-.6-2.1z"/></svg>';
  var sendIcon =
    '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>';

  root.innerHTML =
    "<style>" + styles + "</style>" +
    '<button class="launcher" aria-label="Abrir asistente de garantías">' +
      '<span class="dot"></span>' +
      "<span>Ayuda con garantías</span>" +
    "</button>" +
    '<section class="panel" role="dialog" aria-label="Asistente de garantías">' +
      '<div class="head">' +
        '<div class="badge">' + wrench + "</div>" +
        "<div>" +
          '<div class="title">Asistente de garantías</div>' +
          '<div class="sub mono">Repuestos automotrices</div>' +
        "</div>" +
        '<button class="close" aria-label="Cerrar">&times;</button>' +
      "</div>" +
      '<div class="log" id="log"></div>' +
      '<div class="foot">' +
        '<div class="row">' +
          '<textarea id="input" rows="1" placeholder="Escribe tu consulta…" aria-label="Mensaje"></textarea>' +
          '<button class="send" id="send" aria-label="Enviar">' + sendIcon + "</button>" +
        "</div>" +
        '<p class="disclaimer">Orientación preliminar. La resolución final del reclamo corresponde al fabricante.</p>' +
      "</div>" +
    "</section>";

  var launcher = root.querySelector(".launcher");
  var panel = root.querySelector(".panel");
  var closeBtn = root.querySelector(".close");
  var log = root.getElementById("log");
  var input = root.getElementById("input");
  var sendBtn = root.getElementById("send");

  function escapeHtml(s) {
    return s
      .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  }

  // Render muy ligero: bloques ``` -> <pre>, **negrita** -> <strong>.
  function render(text) {
    var parts = text.split(/```/);
    var out = "";
    for (var i = 0; i < parts.length; i++) {
      if (i % 2 === 1) {
        out += "<pre>" + escapeHtml(parts[i].replace(/^\n/, "")) + "</pre>";
      } else {
        var t = escapeHtml(parts[i]).replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>");
        out += t;
      }
    }
    return out;
  }

  function addMsg(role, text) {
    var el = document.createElement("div");
    el.className = "msg " + (role === "user" ? "user" : "bot");
    if (role === "user") el.textContent = text;
    else el.innerHTML = render(text);
    log.appendChild(el);
    log.scrollTop = log.scrollHeight;
    return el;
  }

  function showTyping() {
    var t = document.createElement("div");
    t.className = "typing";
    t.id = "typing";
    t.innerHTML = "<span></span><span></span><span></span>";
    log.appendChild(t);
    log.scrollTop = log.scrollHeight;
  }
  function hideTyping() {
    var t = root.getElementById("typing");
    if (t) t.remove();
  }

  function openPanel() {
    panel.classList.add("open");
    launcher.style.display = "none";
    input.focus();
  }
  function closePanel() {
    panel.classList.remove("open");
    launcher.style.display = "inline-flex";
  }

  var started = false;
  launcher.addEventListener("click", function () {
    openPanel();
    if (!started) {
      started = true;
      addMsg("bot", WELCOME);
    }
  });
  closeBtn.addEventListener("click", closePanel);

  function autosize() {
    input.style.height = "auto";
    input.style.height = Math.min(input.scrollHeight, 110) + "px";
  }
  input.addEventListener("input", autosize);

  async function send() {
    var text = input.value.trim();
    if (!text || sending) return;
    sending = true;
    sendBtn.disabled = true;

    addMsg("user", text);
    history.push({ role: "user", content: text });
    input.value = "";
    autosize();
    showTyping();

    try {
      var res = await fetch(ENDPOINT, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ messages: history }),
      });
      var data = await res.json();
      hideTyping();
      if (!res.ok || data.error) {
        addMsg("bot", "Lo siento, hubo un problema al responder. Intenta de nuevo en un momento.");
      } else {
        addMsg("bot", data.reply);
        history.push({ role: "assistant", content: data.reply });
      }
    } catch (e) {
      hideTyping();
      addMsg("bot", "No pude conectar con el servidor. Revisa tu conexión e intenta otra vez.");
    } finally {
      sending = false;
      sendBtn.disabled = false;
      input.focus();
    }
  }

  sendBtn.addEventListener("click", send);
  input.addEventListener("keydown", function (e) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      send();
    }
  });
})();
