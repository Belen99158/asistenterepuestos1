# Asistente de Garantías — Widget para tu web

Un asistente de ayuda que se incrusta en tu página y orienta a los clientes sobre
garantías de repuestos automotrices. La "inteligencia" viene del system prompt en
`functions/api/_prompt.js`, generado a partir del skill de evaluación de garantías.

## Costos (importante)

- **Hosting (Cloudflare Pages): gratis.** Plan gratuito, sin tarjeta, uso comercial
  permitido, hasta 100.000 solicitudes/día.
- **API de Claude: se paga por uso** a Anthropic, por tokens. Es barato por mensaje,
  pero necesitas una cuenta con saldo en https://console.anthropic.com. Esto no se
  puede evitar si quieres que responda Claude.

## Cómo está armado

```
asistente-garantia-web/
├── index.html                       ← página de demo que incrusta el widget
├── widget/
│   └── asistente-garantia.js        ← el widget (esto va en tu página real)
├── functions/
│   └── api/
│       ├── chat.js                  ← backend: oculta la clave y llama a Claude
│       └── _prompt.js               ← el "cerebro" (system prompt) del asistente
├── package.json
├── .dev.vars.example
└── .gitignore
```

**Tres piezas:** el widget (navegador) → tu backend `/api/chat` (guarda la clave en
secreto) → la API de Claude. La clave **nunca** llega al navegador.

> En Cloudflare Pages, el archivo `functions/api/chat.js` se publica automáticamente
> en la ruta `/api/chat`. No tienes que configurar rutas.

---

## Puesta en marcha (GitHub + Cloudflare Pages) — gratis

### 1. Sube el proyecto a GitHub
Crea un repositorio nuevo y sube estos archivos. Por terminal:
```bash
git init
git add .
git commit -m "Asistente de garantias inicial"
git branch -M main
git remote add origin https://github.com/TU-USUARIO/asistente-garantia-web.git
git push -u origin main
```
(O usa "uploading an existing file" desde la web de GitHub si no quieres terminal.)

### 2. Consigue tu clave de API
- Entra a https://console.anthropic.com → API Keys → crea una.
- Cópiala (empieza con `sk-ant-...`). **No la pongas en el código ni en GitHub.**

### 3. Crea el proyecto en Cloudflare Pages
- Entra a https://dash.cloudflare.com → Workers & Pages → **Create** → **Pages** →
  **Connect to Git**.
- Elige tu repositorio.
- En la configuración de build, déjalo vacío (es un sitio estático con functions):
  - Framework preset: **None**
  - Build command: *(vacío)*
  - Build output directory: `/` (la raíz)
- Despliega.

### 4. Configura la clave como secreto
- En el proyecto de Pages → **Settings → Environment variables** (o **Variables and
  Secrets**) → agrega:
  - Nombre: `ANTHROPIC_API_KEY`
  - Valor: tu clave `sk-ant-...`  (márcala como *Secret* si te da la opción)
- Vuelve a desplegar (Retry deployment) para que tome la variable.

### 5. Listo
Cloudflare te da una URL (p. ej. `https://asistente-garantia-web.pages.dev`).
Ábrela y prueba el botón "Ayuda con garantías" abajo a la derecha.

---

## Cómo ponerlo en TU página real

Agrega **una línea** antes de `</body>`:

```html
<script src="https://TU-DOMINIO/widget/asistente-garantia.js"
        data-endpoint="https://TU-DOMINIO/api/chat"></script>
```

`data-endpoint` debe apuntar al backend que desplegaste.

---

## Ajustes útiles

- **Modelo / costo:** en `functions/api/chat.js`, variable `MODEL`.
  `claude-haiku-4-5-20251001` es más barato; `claude-sonnet-4-6` (por defecto) razona mejor.
- **Seguridad del origen:** en `functions/api/chat.js`, cambia `ALLOWED_ORIGIN` de `"*"`
  a tu dominio real cuando salgas a producción.
- **Bienvenida y título:** en `widget/asistente-garantia.js` (constante `WELCOME` y los
  textos del encabezado).
- **Cambiar el "cerebro":** edita el skill y regenera `functions/api/_prompt.js`, o edita
  ese archivo directamente.

## Probar en tu computadora (opcional)

```bash
npm i -g wrangler
cp .dev.vars.example .dev.vars   # pon tu clave dentro
npx wrangler pages dev .         # abre el sitio local con el backend
```

---

## Otras plataformas gratuitas

Si prefieres Netlify, la lógica del backend es la misma; solo cambia la "envoltura"
de la función (Netlify usa `netlify/functions/` y `exports.handler`). El widget y el
system prompt no cambian. Avísame y te lo adapto.
